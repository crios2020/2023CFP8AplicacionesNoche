package ar.org.centro8.curso.especialidad.web.server.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet(name = "calculadoraservlet", urlPatterns = "/calculadoraServlet")
public class CalculadoraServlet extends HttpServlet{
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/plain");
        try (PrintWriter out=response.getWriter()) {
            //http://localhost:8082/calculadoraServlet?operacion=dividir&nro1=77&nro2=88
            double nro1=Double.parseDouble(request.getParameter("nro1"));
            double nro2=Double.parseDouble(request.getParameter("nro2"));
            String operacion=request.getParameter("operacion");
            
            switch(operacion){
                case "sumar":       out.println(nro1+nro2);         break;
                case "restar":      out.println(nro1-nro2);         break;
                case "multiplicar": out.println(nro1*nro2);         break;
                case "dividir":
                                    if(nro2!=0){
                                        out.println(nro1/nro2);
                                    }else{
                                        out.println("Error div/0");
                                    }
                    break;
                default:            out.println("Operación incorrecta, solo se permite 'sumar', 'restar', 'dividir' y 'multiplicar'");
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        // try (PrintWriter out=response.getWriter()) {
        //     out.println("0");
        // }
        
    }
}
