package ar.org.centro8.curso.especialidad.web.server.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ControllerWeb {
    
    @GetMapping("/")
    public String getIndex(){
        return "index";
    }

    @GetMapping("/sumar")
    public String getSumar(){
        return "sumar";
    }

}
